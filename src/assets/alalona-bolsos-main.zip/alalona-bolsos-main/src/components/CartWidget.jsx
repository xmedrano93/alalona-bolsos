import carrito from "../assets/carro.png"

function CartWidget (){
    return (
            <img alt="carrito"src={carrito}></img>
    )
}

export default CartWidget;