function ItemListContainer ({greeting}) {
    return(
           <h3 className="text-success wrap">{greeting}</h3> 
    );
}

export default ItemListContainer;