import "./styles/App.css"
import NavBar from "./components/NavBar"
import ItemListContainer from "./components/ItemListContainer"

function App() {
  return (
    <>
      <NavBar />
      <ItemListContainer greeting="Producto 'A'"/>
      <ItemListContainer greeting="Producto 'B'"/>
      <ItemListContainer greeting="Producto 'C'"/>
    </>
  );
}

export default App;
